int main(){
		int i = 0;
		for (;i < 10;i++){
			Yield();
		}
	}