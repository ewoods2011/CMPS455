int main(){
	Join(Exec("../test2/blank"));
	}
