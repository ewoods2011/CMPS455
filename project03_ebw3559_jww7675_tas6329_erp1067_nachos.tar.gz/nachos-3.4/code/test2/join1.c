int main(){
	int a;
	a=Exec("../test2/matmult");
	Join(a);
}