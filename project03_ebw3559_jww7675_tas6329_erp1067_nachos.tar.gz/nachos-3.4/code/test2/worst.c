#include "syscall.h"

int main(){
	Exec("../test2/matmult2");
	Exit(0);
	}