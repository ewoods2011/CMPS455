int main(){
	Exec("../test2/thisisnotaprogramname");
}