int main(){
	Join(-100);
}