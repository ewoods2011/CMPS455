#include "syscall.h"

int main(){
	Exec("../test2/repeat");
	Exec("../test2/repeat");
	Exec("../test2/blank");
	Exit(0);
	}