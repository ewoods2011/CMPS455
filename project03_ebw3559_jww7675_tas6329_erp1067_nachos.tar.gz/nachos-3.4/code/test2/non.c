int main(){
	Exec("../test2/halt.c");
}