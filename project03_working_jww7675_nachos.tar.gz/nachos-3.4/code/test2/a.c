int main(){
	Write("a",1,1);
}