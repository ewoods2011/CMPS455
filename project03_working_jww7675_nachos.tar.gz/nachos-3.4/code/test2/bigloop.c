/* matmult2.c
*  Loops lots.
*
*/

#include "syscall.h"

int main(){
	int i = 0;
	int j = 0;
	
	for (;i < 10000; ++i){
		++j;
	}
}