int main(){
	Exec("../test2/a");
}