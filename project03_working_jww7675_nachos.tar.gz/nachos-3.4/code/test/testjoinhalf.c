int main(){
	Join(Exec("../test/test2"));
	}