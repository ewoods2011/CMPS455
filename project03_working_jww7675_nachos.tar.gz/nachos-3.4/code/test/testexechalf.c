int main(){
	Exec("../test/test2");
	Yield();
	Exit(0);
	}